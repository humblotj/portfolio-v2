/* eslint-disable react/jsx-props-no-spreading */
import { Route, Switch } from 'react-router-dom';
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';
import { FirestoreProvider } from '@react-firebase/firestore';
import firebase from 'firebase';

import './App.scss';
import Header from './components/Header';
import Loading from './components/Loading';
import ScrollToTop from './components/ScrollToTop';
import SideLeft from './components/SideLeft';
import Strokes from './components/Strokes';
import StoreProvider from './context/StoreProvider';
import AboutContact from './pages/about-me/AboutContact';
import Main from './pages/main/Main';
import WorkDetail from './pages/work-detail/WorkDetail';

gsap.registerPlugin(ScrollTrigger);

const config = JSON.parse(process.env.REACT_APP_API_KEY || '{}');
firebase.initializeApp(config);

const App = () => (
  <FirestoreProvider firebase={firebase} {...config}>
    <ScrollToTop />
    <StoreProvider>
      <Header />
      <Strokes />
      <SideLeft />
      <Loading />
      <Switch>
        <Route path="/work/:id">
          <WorkDetail />
        </Route>
        <Route path="/">
          <Main />
        </Route>
      </Switch>
      <AboutContact />
    </StoreProvider>
  </FirestoreProvider>
);

export default App;
